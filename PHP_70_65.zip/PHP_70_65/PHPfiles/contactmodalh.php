 <?php include('session.php'); ?>
 <!-- The Modal -->
<divm id="contacth" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="closec">&times;</span>
    <form name="contact_formh" method="post" action="home.html" onsubmit="return validate_contacth();">
    <h1 style="text-align:center">Contact Us</h1>
<p style="font-size:18px">Name</p>
<input name="txt_fullnamech" type="text" id="txt_fullnamech" placeholder="Your Name"/>
<p style="font-size:18px">Email</p>
<input name="txt_emailch" type="text" id="txt_emailch" placeholder="Your email address"/>
<p style="font-size:18px">Inquiry</p>
<textarea name="txt_inquirych" rows="5"   type="text" id="txt_inquirych" placeholder="Your inquiry"></textarea>

<p>
  <input type="submit" name="contact_btn_submith" id="contact_btn_submith" value="Submit" />
  
</p>

<p style="font-size:12px">For more details call: 011-2451932</p>

</form>
  </div>

</divm>

<script type="text/javascript">
// Get the modal
var contactmodalh = document.getElementById('contacth');

// Get the button that opens the modal
var contactbtnh = document.getElementById("contact_btnch");

// Get the <span> element that closes the modal
var contactspanh = document.getElementsByClassName("closec")[0];

// When the user clicks the button, open the modal 
contactbtnh.onclick = function() {
    contactmodalh.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
contactspanh.onclick = function() {
    contactmodalh.style.display = "none";
}

function validate_contacth()
{
	var namech=document.contact_formh.txt_fullnamech;
	var emailch=document.contact_formh.txt_emailch;
	var inquirych=document.contact_formh.txt_inquirych;
	
	if(EmptyValidationcontacth(namech,emailch,inquirych))
	{
		if(AllLetterscontacth(namech))
		{
			if(Emailcontacth(emailch))
			{
				alert("Your inquiry is sent successfully");
				return true;
			}
		}
		
	}
	return false;
	
	
}

function EmptyValidationcontacth(namech,emailch,inquirych)
{
	var name_lengthch=namech.value.length;
	var email_lengthch=emailch.value.length;
	var inquiry_lengthch=inquirych.value.length;
	
	if(name_lengthch==0||email_lengthch==0||inquiry_lengthch==0)
	{
		alert("Fields should not be empty");
		return false;
			
	}
	else
	{
		return true;
	}
	
}

function AllLetterscontacth(namech)
{
	var lettersch=/^[A-Za-z]+$/;
	if(namech.value.match(lettersch))
	{
		return true;
	}
	else
	{
		alert("Name should contain only alphabets");
		namech.focus();
		return false;
	}
}


function Emailcontacth(emailch)
{
	var letterch=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if(emailch.value.match(letterch))
	{
		return true;
	}
	else
	{
		alert("Invalid email format");
		emailch.focus();
		return false;
	}
}


</script>

<?php
if(isset($_POST['contact_btn_submith']))
{
include('connection.php');

$namech=$_POST['txt_fullnamech'];
$emailch=$_POST['txt_emailch'];
$mobilech=$_POST['txt_mobilech'];

$sqlch="insert into tbl_inquirydetails values('$login_session','$namech','$emailch','$mobilech')";
$datach=mysqli_query($conn,$sqlch);
if($datach)
{
echo "You inquiry has been sent";
}
else
{
die('could not enter data'.mysqli_error());
}
}

?>
