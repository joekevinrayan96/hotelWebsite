

<?php
include('connection.php');

if($_SERVER["REQUEST_METHOD"]=="POST"){
	session_start();
$myusernamed=$_POST['txt_usernamed'];
$mypasswordd=$_POST['txt_passwordd'];
$sqld="select * from tbl_userdetails where username='$myusernamed' and password='$mypasswordd'";

$resultd=mysqli_query($conn,$sqld);
$rowd=mysqli_fetch_array($resultd,MYSQLI_ASSOC);
$countd=mysqli_num_rows($resultd);

if($countd==1){
$_SESSION['login_user']=$myusernamed;
$loginsuccessmessaged="Login successfull";
echo "<script type='text/javascript'>
alert('$loginsuccessmessaged');
 window.location='home1.php';
</script>";
//header("location:home1.php");
}
else{
$errord="Username or Password incorrect";
echo "<script type='text/javascript'>
alert('$errord');

</script>";
//header("location:loginmodal.php");
}
}


echo '<divm id="logind" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="closel">&times;</span>
    
    <form name="login_formd" method="post" action="" onsubmit="return validate_logind();">
    <h1 style="text-align:center">Login</h1>
	<p style="font-size:18px">Username</p>
	<input name="txt_usernamed" type="text" id="txt_usernamed" placeholder="Enter username"/>
	<p style="font-size:18px">Password</p>
	<input name="txt_passwordd" type="password" id="txt_passwordd" placeholder="Enter password"/>
	<p>
  	<input type="submit" name="login_btn_submitd" id="login_btn_submitd" value="Login" />
    </p>
    <p style="text-align:center">or</p>
    <p>
    <ul class="menu" style="text-align:center">
  	<lil id="register_btnd" ><a href="#register">Register</a></lil>
        </ul>
    </p>
</form>
  </div>

</divm>';

echo "<script type='text/javascript'>
// Get the modal
var loginmodald = document.getElementById('logind');

// Get the button that opens the modal
var loginbtnd = document.getElementById('login_btnd');
var loginbtncd = document.getElementById('login_btncd');
var loginbtnbd = document.getElementById('login_btnbd');

// Get the <span> element that closes the modal
var loginspand = document.getElementsByClassName('closel')[0];


// When the user clicks the button, open the modal 
loginbtnd.onclick = function() {
    loginmodald.style.display = 'block';
}
loginbtncd.onclick = function() {
    loginmodald.style.display = 'block';
}
loginbtnbd.onclick = function() {
    loginmodald.style.display = 'block';
}


// When the user clicks on <span> (x), close the modal
loginspand.onclick = function() {
    loginmodald.style.display = 'none';
}

function validate_logind()
{
	var usernamed=document.login_formd.txt_usernamed;
	var passwordd=document.login_formd.txt_passwordd;
	
	if(EmptyValidationlogind(usernamed,passwordd))
	{
		
		return true;
	}
	return false;
}

function EmptyValidationlogind(usernamed,passwordd)
{
	var username_lengthd=usernamed.value.length;
	var password_lengthd=passwordd.value.length;
	
	if(username_lengthd==0||password_lengthd==0)
	{
		alert('Please enter Username and Password');
		return false;
	}
	else
	{
		return true;
	}
}

</script>";
?>
