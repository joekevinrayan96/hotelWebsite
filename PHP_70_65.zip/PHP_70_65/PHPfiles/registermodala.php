<divm id="registera" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="closer">&times;</span>
    <form name="register_forma" method="post" action="" onsubmit="return validate_registera();">
    <h1 style="text-align:center">Register</h1>
<p style="font-size:18px">First Name</p>
<input name="txt_firstnamera" type="text" id="txt_firstnamera" placeholder="Your First Name"/>
<p style="font-size:18px">Last Name</p>
<input name="txt_lastnamera" type="text" id="txt_lastnamera" placeholder="Your Last Name"/>
<p style="font-size:18px">Email</p>
<input name="txt_emailra" type="text" id="txt_emailra" placeholder="Your email address"/>
<p style="font-size:18px">Contact No</p>
<input name="txt_mobilera" type="text" id="txt_mobilera" placeholder="Your mobile No." />
<p style="font-size:18px">Username</p>
<input name="txt_usernamera" type="text" id="txt_usernamera" placeholder="Create a username" />
<p style="font-size:18px">Password</p>
<input name="txt_passwordra" type="password" id="txt_passwordra" placeholder="Enter a password" />
<p style="font-size:18px">Re-enter Password</p>
<input name="txt_repasswordra" type="text" id="txt_repasswordra" placeholder="Re-enter the password" />

<p>
  <input type="submit" name="register_btn_submitra" id="register_btn_submitra" value="Submit" />
</p>
</form>
  </div>

</divm>

<script type="text/javascript">
// Get the modal
var registermodala = document.getElementById('registera');

// Get the button that opens the modal
var registerbtna = document.getElementById("register_btna");

// Get the <span> element that closes the modal
var registerspana = document.getElementsByClassName("closer")[0];

// When the user clicks the button, open the modal 
registerbtna.onclick = function() {
    registermodala.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
registerspana.onclick = function() {
    registermodala.style.display = "none";
}

function validate_registera()
{
	var firstnamera=document.register_forma.txt_firstnamera;
	var lastnamera=document.register_forma.txt_lastnamera;
	var emailra=document.register_forma.txt_emailra;
	var contactnora=document.register_forma.txt_mobilera;
	var usernamera=document.register_forma.txt_usernamera;
	var passwordra=document.register_forma.txt_passwordra;
	var repasswordra=document.register_forma.txt_repasswordra;
	
	if(EmptyValidationregistera(firstnamera,lastnamera,emailra,contactnora,usernamera,passwordra,repasswordra))
	{
		if(AllLettersregistera(firstnamera,lastnamera))
		{
			if(Emailregistera(emailra))
			{
				if(Allnumericregistera(contactnora))
				{
					if(passwordra.getText().toString().equals(repasswordra))
					{
						alert("You have successfully registered");
							return true;
					}
				}
			}
		}
		
	}
	return false;
	
	
}

function EmptyValidationregistera(firstnamera,lastnamera,emailra,contactnora,usernamera,passwordra,repasswordra)
{
	var firstname_lengthra=firstnamera.value.length;
	var lastname_lengthra=lastnamera.value.length;
	var email_lengthra=emailra.value.length;
	var contactno_lengthra=contactnora.value.length;
	var username_lengthra=usernamera.value.length;
	var password_lengthra=passwordra.value.length;
	var repassword_lengthra=repasswordra.value.length;
	
	if(firstname_lengthra==0||lastname_lengthra==0||email_lengthra==0||contactno_lengthra==0||username_lengthra==0||password_lengthra==0||repassword_lengthra==0)
	{
		alert("Fields should not be empty");
		return false;
			
	}
	else
	{
		return true;
	}
	
}

function AllLettersregistera(firstnamebra,lastnamera)
{
	var lettersra=/^[A-Za-z]+$/;
	if(firstnamera.value.match(lettersra)&&lastnamera.value.match(lettersra))
	{
		return true;
	}
	else
	{
		alert('Firstname and Lastname should contain only alphabets');
		firstnamera.focus();
		return false;
	}
}


function Emailregistera(emailra)
{
	var letterra=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if(emailra.value.match(letterra))
	{
		return true;
	}
	else
	{
		alert("Invalid email format")
		emailra.focus();
		return false;
	}
}

function Allnumericregistera(contactnora)
{
	var lettersnra=/^[0-9]+$/;
	if(contactnora.value.match(lettersnra))
	{
		return true;
	}
	else
	{
		alert("mobile no should contain only numbers");
		mobilera.focus();
		return false;
	}
}




</script>

<?php
if(isset($_POST['register_btn_submitra']))
{
include('connection.php');

$firstnamera=$_POST['txt_firstnamera'];
$lastnamera=$_POST['txt_lastnamera'];
$emailra=$_POST['txt_emailra'];
$mobilera=$_POST['txt_mobilera'];
$usernamera=$_POST['txt_usernamera'];
$passwordra=$_POST['txt_passwordra'];

$checkra="select * from tbl_userdetails where username='$usernamera'";
$rsa=mysqli_query($conn,$checkra);
$data1ra=mysqli_fetch_array($rsa, MYSQLI_NUM);
if($data1ra[0]>1)
{
	echo "User already exists</br>";
}
else
{
	
$sqlra="insert into tbl_userdetails values('$firstnamera','$lastnamera','$emailra','$mobilera','$usernamera','$passwordra')";
$datara=mysqli_query($conn,$sqlra);
	if($datara)
	{
		echo "You have successfully registered";
	}
	else
	{
		die('could not enter data'.mysqli_error());
	}
}

}
?>
