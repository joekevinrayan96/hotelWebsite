

<?php
include('connection.php');

if($_SERVER["REQUEST_METHOD"]=="POST"){
	session_start();
$myusernamea=$_POST['txt_usernamea'];
$mypassworda=$_POST['txt_passworda'];
$sqla="select * from tbl_userdetails where username='$myusernamea' and password='$mypassworda'";

$resulta=mysqli_query($conn,$sqla);
$rowa=mysqli_fetch_array($resulta,MYSQLI_ASSOC);
$counta=mysqli_num_rows($resulta);

if($counta==1){
$_SESSION['login_user']=$myusernamea;
$loginsuccessmessagea="Login successfull";
echo "<script type='text/javascript'>
alert('$loginsuccessmessagea');
 window.location='home1.php';
</script>";
//header("location:home1.php");
}
else{
$errora="Username or Password incorrect";
echo "<script type='text/javascript'>
alert('$errora');

</script>";
//header("location:loginmodal.php");
}
}


echo '<divm id="logina" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="closel">&times;</span>
    
    <form name="login_forma" method="post" action="" onsubmit="return validate_logina();">
    <h1 style="text-align:center">Login</h1>
	<p style="font-size:18px">Username</p>
	<input name="txt_usernamea" type="text" id="txt_usernamea" placeholder="Enter username"/>
	<p style="font-size:18px">Password</p>
	<input name="txt_passworda" type="password" id="txt_passworda" placeholder="Enter password"/>
	<p>
  	<input type="submit" name="login_btn_submita" id="login_btn_submita" value="Login" />
    </p>
    <p style="text-align:center">or</p>
    <p>
    <ul class="menu" style="text-align:center">
  	<lil id="register_btna" ><a href="#register">Register</a></lil>
        </ul>
    </p>
</form>
  </div>

</divm>';

echo "<script type='text/javascript'>
// Get the modal
var loginmodala = document.getElementById('logina');

// Get the button that opens the modal
var loginbtna = document.getElementById('login_btna');
var loginbtnca = document.getElementById('login_btnca');
var loginbtnba = document.getElementById('login_btnba');

// Get the <span> element that closes the modal
var loginspana = document.getElementsByClassName('closel')[0];


// When the user clicks the button, open the modal 
loginbtna.onclick = function() {
    loginmodala.style.display = 'block';
}
loginbtnca.onclick = function() {
    loginmodala.style.display = 'block';
}
loginbtnba.onclick = function() {
    loginmodala.style.display = 'block';
}


// When the user clicks on <span> (x), close the modal
loginspana.onclick = function() {
    loginmodala.style.display = 'none';
}

function validate_logina()
{
	var usernamea=document.login_forma.txt_usernamea;
	var passworda=document.login_forma.txt_passworda;
	
	if(EmptyValidationlogina(usernamea,passworda))
	{
		
		return true;
	}
	return false;
}

function EmptyValidationlogina(usernamea,passworda)
{
	var username_lengtha=usernamea.value.length;
	var password_lengtha=passworda.value.length;
	
	if(username_lengtha==0||password_lengtha==0)
	{
		alert('Please enter Username and Password');
		return false;
	}
	else
	{
		return true;
	}
}

</script>";
?>
