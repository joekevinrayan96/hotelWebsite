<?php include('session.php'); ?>
 <!-- The Modal -->
<divm id="contacta" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="closec">&times;</span>
    <form name="contact_forma" method="post" action="home.html" onsubmit="return validate_contacta();">
    <h1 style="text-align:center">Contact Us</h1>
<p style="font-size:18px">Name</p>
<input name="txt_fullnameca" type="text" id="txt_fullnameca" placeholder="Your Name"/>
<p style="font-size:18px">Email</p>
<input name="txt_emailca" type="text" id="txt_emailca" placeholder="Your email address"/>
<p style="font-size:18px">Inquiry</p>
<textarea name="txt_inquiryca" rows="5"   type="text" id="txt_inquiryca" placeholder="Your inquiry"></textarea>

<p>
  <input type="submit" name="contact_btn_submita" id="contact_btn_submita" value="Submit" />
  
</p>

<p style="font-size:12px">For more details call: 011-2451932</p>

</form>
  </div>

</divm>

<script type="text/javascript">
// Get the modal
var contactmodala = document.getElementById('contacta');

// Get the button that opens the modal
var contactbtna = document.getElementById("contact_btnca");

// Get the <span> element that closes the modal
var contactspana = document.getElementsByClassName("closec")[0];

// When the user clicks the button, open the modal 
contactbtna.onclick = function() {
    contactmodala.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
contactspana.onclick = function() {
    contactmodala.style.display = "none";
}

function validate_contacta()
{
	var nameca=document.contact_forma.txt_fullnameca;
	var emailca=document.contact_forma.txt_emailca;
	var inquiryca=document.contact_forma.txt_inquiryca;
	
	if(EmptyValidationcontacta(nameca,emailca,inquiryca))
	{
		if(AllLetterscontacta(nameca))
		{
			if(Emailcontacta(emailca))
			{
				alert("Your inquiry is sent successfully");
				return true;
			}
		}
		
	}
	return false;
	
	
}

function EmptyValidationcontacta(nameca,emailca,inquiryca)
{
	var name_lengthca=nameca.value.length;
	var email_lengthca=emailca.value.length;
	var inquiry_lengthca=inquiryca.value.length;
	
	if(name_lengthca==0||email_lengthca==0||inquiry_lengthca==0)
	{
		alert("Fields should not be empty");
		return false;
			
	}
	else
	{
		return true;
	}
	
}

function AllLetterscontacta(nameca)
{
	var lettersca=/^[A-Za-z]+$/;
	if(nameca.value.match(lettersca))
	{
		return true;
	}
	else
	{
		alert("Name should contain only alphabets");
		nameca.focus();
		return false;
	}
}


function Emailcontacta(emailca)
{
	var letterca=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if(emailca.value.match(letterca))
	{
		return true;
	}
	else
	{
		alert("Invalid email format");
		emailca.focus();
		return false;
	}
}


</script>

<?php
if(isset($_POST['contact_btn_submita']))
{
include('connection.php');

$nameca=$_POST['txt_fullnameca'];
$emailca=$_POST['txt_emailca'];
$mobileca=$_POST['txt_mobileca'];

$sqlca="insert into tbl_inquirydetails values('$login_session','$nameca','$emailca','$mobileca')";
$dataca=mysqli_query($conn,$sqlca);
if($dataca)
{
echo "You inquiry has been sent";
}
else
{
die('could not enter data'.mysqli_error());
}
}

?>
