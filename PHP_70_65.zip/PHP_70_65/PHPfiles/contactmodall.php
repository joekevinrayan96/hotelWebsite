<?php include('session.php'); ?>
 <!-- The Modal -->
<divm id="contactl" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="closec">&times;</span>
    <form name="contact_forml" method="post" action="home.html" onsubmit="return validate_contactl();">
    <h1 style="text-align:center">Contact Us</h1>
<p style="font-size:18px">Name</p>
<input name="txt_fullnamecl" type="text" id="txt_fullnamecl" placeholder="Your Name"/>
<p style="font-size:18px">Email</p>
<input name="txt_emailcl" type="text" id="txt_emailcl" placeholder="Your email address"/>
<p style="font-size:18px">Inquiry</p>
<textarea name="txt_inquirycl" rows="5"   type="text" id="txt_inquirycl" placeholder="Your inquiry"></textarea>

<p>
  <input type="submit" name="contact_btn_submitl" id="contact_btn_submitl" value="Submit" />
  
</p>

<p style="font-size:12px">For more details call: 011-2451932</p>

</form>
  </div>

</divm>

<script type="text/javascript">
// Get the modal
var contactmodall = document.getElementById('contactl');

// Get the button that opens the modal
var contactbtnl = document.getElementById("contact_btncl");

// Get the <span> element that closes the modal
var contactspanl = document.getElementsByClassName("closec")[0];

// When the user clicks the button, open the modal 
contactbtnl.onclick = function() {
    contactmodall.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
contactspanl.onclick = function() {
    contactmodall.style.display = "none";
}

function validate_contactl()
{
	var namecl=document.contact_forml.txt_fullnamecl;
	var emailcl=document.contact_forml.txt_emailcl;
	var inquirycl=document.contact_forml.txt_inquirycl;
	
	if(EmptyValidationcontactl(namecl,emailcl,inquirycl))
	{
		if(AllLetterscontactl(namecl))
		{
			if(Emailcontactl(emailcl))
			{
				alert("Your inquiry is sent successfully");
				return true;
			}
		}
		
	}
	return false;
	
	
}

function EmptyValidationcontactl(namecl,emailcl,inquirycl)
{
	var name_lengthcl=namecl.value.length;
	var email_lengthcl=emailcl.value.length;
	var inquiry_lengthcl=inquirycl.value.length;
	
	if(name_lengthcl==0||email_lengthcl==0||inquiry_lengthcl==0)
	{
		alert("Fields should not be empty");
		return false;
			
	}
	else
	{
		return true;
	}
	
}

function AllLetterscontactl(namecl)
{
	var letterscl=/^[A-Za-z]+$/;
	if(namecl.value.match(letterscl))
	{
		return true;
	}
	else
	{
		alert("Name should contain only alphabets");
		namecl.focus();
		return false;
	}
}


function Emailcontactl(emailcl)
{
	var lettercl=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if(emailcl.value.match(lettercl))
	{
		return true;
	}
	else
	{
		alert("Invalid email format");
		emailcl.focus();
		return false;
	}
}


</script>

<?php
if(isset($_POST['contact_btn_submitl']))
{
include('connection.php');

$namecl=$_POST['txt_fullnamecl'];
$emailcl=$_POST['txt_emailcl'];
$mobilecl=$_POST['txt_mobilecl'];

$sqlcl="insert into tbl_inquirydetails values('$login_session','$namecl','$emailcl','$mobilecl')";
$datacl=mysqli_query($conn,$sqlcl);
if($datacl)
{
echo "You inquiry has been sent";
}
else
{
die('could not enter data'.mysqli_error());
}
}

?>
