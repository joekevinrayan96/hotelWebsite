<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style>
table, th, td {
    border: 1px solid black;
}
</style>
</head>

<body>
<?php
include('connection.php');
echo '
<form name="adminbook_form" method="post" action="" onsubmit="">
<p style="font-size:18px">Enter ID</p>
	<input name="txt_idab" type="text" id="txt_idab" placeholder="Enter username"/>
	<p>
  	<input type="submit" name="btn_deleteab" id="btn_deleteab" value="Delete" />
    </p>
	</form>
	';
	
if($_SERVER["REQUEST_METHOD"]=="POST"){
	session_start();
$idab=$_POST['txt_idab'];

$sqldeleteab="delete from tbl_bookdetails where id='$idab'";

$delab=mysqli_query($conn,$sqldeleteab);
//$rowai=mysqli_fetch_array($delai,MYSQLI_ASSOC);
//$countai=mysqli_num_rows($delai);

//if($countai==1){
if($delab)
{
$deletesuccessmessageab="Delete successful";
echo "<script type='text/javascript'>
alert('$deletesuccessmessageab');
 
</script>";
}

//header("location:home1.php");
//}


//header("location:loginmodal.php");
//}
}




$sqlab = "SELECT * FROM tbl_bookdetails";
$resultab=mysqli_query($conn,$sqlab);

if ($resultab->num_rows > 0) {
    echo "<table><tr><th>Firstname</th><th>Lastname</th><th>Email</th><th>Contact No</th><th>Check in</th><th>Check out</th>
	<th>Room Type</th><th>Username</th><th>ID</th></tr>";
    // output data of each row
    while($rowab = $resultab->fetch_assoc()) {
        echo "<tr><td>".$rowab["Firstname"]."</td><td>".$rowab["Lastname"]."</td><td>".$rowab["Email"]."</td><td>".$rowab["ContactNo"]
		."</td><td>".$rowab["Checkin"]."</td><td>".$rowab["Checkout"]."</td><td>".$rowab["RoomType"]
		."</td><td>".$rowab["username"]."</td><td>".$rowab["id"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}


?> 
</body>
</html>