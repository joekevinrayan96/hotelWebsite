<?php
if(isset($_POST['register_btn_submitrh']))
{
include('connection.php');

$firstnamerh=$_POST['txt_firstnamerh'];
$lastnamerh=$_POST['txt_lastnamerh'];
$emailrh=$_POST['txt_emailrh'];
$mobilerh=$_POST['txt_mobilerh'];
$usernamerh=$_POST['txt_usernamerh'];
$passwordrh=$_POST['txt_passwordrh'];

$checkrh="select * from tbl_userdetails where username='$usernamerh'";
$rsh=mysqli_query($conn,$checkrh);
$data1rh=mysqli_fetch_array($rsh, MYSQLI_NUM);
if($data1rh[0]>1)
{
	echo "User already exists</br>";
}
else
{
$sqlrh="insert into tbl_userdetails values('$firstnamerh','$lastnamerh','$emailrh','$mobilerh','$usernamerh','$passwordrh')";
$datarh=mysqli_query($conn,$sqlrh);
if($datarh)
{
echo "You have successfully registered";
}
else
{
die('could not enter data'.mysqli_error());
}
}

}
?>

<divm id="registerh" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="closer">&times;</span>
    <form name="register_formh" method="post" action="" onsubmit="return validate_registerh();">
    <h1 style="text-align:center">Register</h1>
<p style="font-size:18px">First Name</p>
<input name="txt_firstnamerh" type="text" id="txt_firstnamerh" placeholder="Your First Name"/>
<p style="font-size:18px">Last Name</p>
<input name="txt_lastnamerh" type="text" id="txt_lastnamerh" placeholder="Your Last Name"/>
<p style="font-size:18px">Email</p>
<input name="txt_emailrh" type="text" id="txt_emailrh" placeholder="Your email address"/>
<p style="font-size:18px">Contact No</p>
<input name="txt_mobilerh" type="text" id="txt_mobilerh" placeholder="Your mobile No." />
<p style="font-size:18px">Username</p>
<input name="txt_usernamerh" type="text" id="txt_usernamerh" placeholder="Create a username" />
<p style="font-size:18px">Password</p>
<input name="txt_passwordrh" type="password" id="txt_passwordrh" placeholder="Enter a password" />
<p style="font-size:18px">Re-enter Password</p>
<input name="txt_repasswordrh" type="password" id="txt_repasswordrh" placeholder="Re-enter the password" />

<p>
  <input type="submit" name="register_btn_submitrh" id="register_btn_submitrh" value="Submit" />
</p>
</form>
  </div>

</divm>

<script type="text/javascript">
// Get the modal
var registermodalh = document.getElementById('registerh');

// Get the button that opens the modal
var registerbtnh = document.getElementById("register_btnh");

// Get the <span> element that closes the modal
var registerspanh = document.getElementsByClassName("closer")[0];

// When the user clicks the button, open the modal 
registerbtnh.onclick = function() {
    registermodalh.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
registerspanh.onclick = function() {
    registermodalh.style.display = "none";
}

function validate_registerh()
{
	var firstnamerh=document.register_formh.txt_firstnamerh;
	var lastnamerh=document.register_formh.txt_lastnamerh;
	var emailrh=document.register_formh.txt_emailrh;
	var contactnorh=document.register_formh.txt_mobilerh;
	var usernamerh=document.register_formh.txt_usernamerh;
	var passwordrh=document.register_formh.txt_passwordrh;
	var repasswordrh=document.register_formh.txt_repasswordrh;
	
	if(EmptyValidationregisterh(firstnamerh,lastnamerh,emailrh,contactnorh,usernamerh,passwordrh,repasswordrh))
	{
		if(AllLettersregisterh(firstnamerh,lastnamerh))
		{
			if(Emailregisterh(emailrh))
			{
				if(Allnumericregisterh(contactnorh))
				{
					if(passwordrh.getText().toString().equals(repasswordrh))
					{
						alert("You have successfully registered");
							return true;
					}
					else
					{
						alert("Passwords do not match in the password and re-type password fields!");
						
					}
				}
			}
		}
		
	}
	return false;
	
	
}

function EmptyValidationregisterh(firstnamerh,lastnamerh,emailrh,contactnorh,usernamerh,passwordrh,repasswordrh)
{
	var firstname_lengthrh=firstnamerh.value.length;
	var lastname_lengthrh=lastnamerh.value.length;
	var email_lengthrh=emailrh.value.length;
	var contactno_lengthrh=contactnorh.value.length;
	var username_lengthrh=usernamerh.value.length;
	var password_lengthrh=passwordrh.value.length;
	var repassword_lengthrh=repasswordrh.value.length;
	
	if(firstname_lengthrh==0||lastname_lengthrh==0||email_lengthrh==0||contactno_lengthrh==0||username_lengthrh==0||password_lengthrh==0||repassword_lengthrh==0)
	{
		alert("Fields should not be empty");
		return false;
			
	}
	else
	{
		return true;
	}
	
}

function AllLettersregisterh(firstnamebrh,lastnamerh)
{
	var lettersrh=/^[A-Za-z]+$/;
	if(firstnamerh.value.match(lettersrh)&&lastnamerh.value.match(lettersrh))
	{
		return true;
	}
	else
	{
		alert('Firstname and Lastname should contain only alphabets');
		firstnamerh.focus();
		return false;
	}
}


function Emailregisterh(emailrh)
{
	var letterrh=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if(emailrh.value.match(letterrh))
	{
		return true;
	}
	else
	{
		alert("Invalid email format")
		emailrh.focus();
		return false;
	}
}

function Allnumericregisterh(contactnorh)
{
	var lettersnrh=/^[0-9]+$/;
	if(contactnorh.value.match(lettersnrh))
	{
		return true;
	}
	else
	{
		alert("mobile no should contain only numbers");
		mobilerh.focus();
		return false;
	}
}




</script>

