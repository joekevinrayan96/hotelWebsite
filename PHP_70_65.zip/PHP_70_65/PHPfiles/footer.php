<footer>
     <table width="100%">
       <tr>
         <td width="33.33%"><img src="../Images/logo.png"/></td>
         <td width="33.33%">
         
         <p style="font-size:16px">
         <i class="material-icons" style="font-size:24pxpx; color:#0FF; text-shadow:2px 2px 4px #000000;">phone</i>&nbsp;  Tel:0112451932
         </p>
         <p>
         <i class="material-icons" style="font-size:24px; color:#0FF; text-shadow:2px 2px 4px #000000;">home</i>&nbsp;75, Folkestone Road, Dover, CT17 9RZ, United Kingdom</p>
         <p><i class="material-icons" style="font-size:24px; color:#0FF; text-shadow:2px 2px 4px #000000;">email</i>&nbsp;      hotelhappyholidaydover@gmail.com</p>
         </td>
         <td width="33.33%" style="text-align:center">
         
         <h3>Like us on</h3>
         <p><a href="https://www.facebook.com/Hotel-Happy-Holiday-1894604327481417/?ref=aymt_homepage_panel"><img src="../Images/facebook_icon.png" style="width:50px; height:50px;"/></a></p>
         </td>
       </tr>
     </table>
   
</footer>
     