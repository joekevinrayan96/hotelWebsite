<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style>
table, th, td {
    border: 1px solid black;
}
</style>
</head>

<body>
<?php
include('connection.php');
echo '
<form name="admininquiry_form" method="post" action="" onsubmit="">
<p style="font-size:18px">Enter ID</p>
	<input name="txt_idai" type="text" id="txt_idai" placeholder="Enter username"/>
	<p>
  	<input type="submit" name="btn_deleteai" id="btn_deleteai" value="Delete" />
    </p>
	</form>
	';
	
if($_SERVER["REQUEST_METHOD"]=="POST"){
	session_start();
$idai=$_POST['txt_idai'];

$sqldeleteai="delete from tbl_inquirydetails where id='$idai'";

$delai=mysqli_query($conn,$sqldeleteai);
//$rowai=mysqli_fetch_array($delai,MYSQLI_ASSOC);
//$countai=mysqli_num_rows($delai);

//if($countai==1){
if($delai)
{
$deletesuccessmessageai="Delete successful";
echo "<script type='text/javascript'>
alert('$deletesuccessmessageai');
 
</script>";
}

//header("location:home1.php");
//}


//header("location:loginmodal.php");
//}
}




$sqlai = "SELECT * FROM tbl_inquirydetails";
$resultai=mysqli_query($conn,$sqlai);

if ($resultai->num_rows > 0) {
    echo "<table><tr><th>Username</th><th>Name</th><th>Email</th><th>Inquiry</th><th>ID</th></tr>";
    // output data of each row
    while($rowai = $resultai->fetch_assoc()) {
        echo "<tr><td>".$rowai["Username"]."</td><td>".$rowai["Name"]."</td><td>".$rowai["Email"]."</td><td>".$rowai["Inquiry"]."</td><td>"
		.$rowai["id"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}


?> 
</body>
</html>