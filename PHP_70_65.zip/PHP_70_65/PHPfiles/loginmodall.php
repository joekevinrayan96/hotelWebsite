

<?php
include('connection.php');

if($_SERVER["REQUEST_METHOD"]=="POST"){
	session_start();
$myusernamel=$_POST['txt_usernamel'];
$mypasswordl=$_POST['txt_passwordl'];
$sqll="select * from tbl_userdetails where username='$myusernamel' and password='$mypasswordl'";

$resultl=mysqli_query($conn,$sqll);
$rowl=mysqli_fetch_array($resultl,MYSQLI_ASSOC);
$countl=mysqli_num_rows($resultl);

if($countl==1){
$_SESSION['login_user']=$myusernamel;
$loginsuccessmessagel="Login successfull";
echo "<script type='text/javascript'>
alert('$loginsuccessmessagel');
 window.location='home1.php';
</script>";
//header("location:home1.php");
}
else{
$errorl="Username or Password incorrect";
echo "<script type='text/javascript'>
alert('$errorl');

</script>";
//header("location:loginmodal.php");
}
}


echo '<divm id="loginl" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="closel">&times;</span>
    
    <form name="login_forml" method="post" action="" onsubmit="return validate_loginl();">
    <h1 style="text-align:center">Login</h1>
	<p style="font-size:18px">Username</p>
	<input name="txt_usernamel" type="text" id="txt_usernamel" placeholder="Enter username"/>
	<p style="font-size:18px">Password</p>
	<input name="txt_passwordl" type="password" id="txt_passwordl" placeholder="Enter password"/>
	<p>
  	<input type="submit" name="login_btn_submitl" id="login_btn_submitl" value="Login" />
    </p>
    <p style="text-align:center">or</p>
    <p>
    <ul class="menu" style="text-align:center">
  	<lil id="register_btnl" ><a href="#register">Register</a></lil>
        </ul>
    </p>
</form>
  </div>

</divm>';

echo "<script type='text/javascript'>
// Get the modal
var loginmodall = document.getElementById('loginl');

// Get the button that opens the modal
var loginbtnl = document.getElementById('login_btnl');
var loginbtncl = document.getElementById('login_btncl');
var loginbtnbl = document.getElementById('login_btnbl');

// Get the <span> element that closes the modal
var loginspanl = document.getElementsByClassName('closel')[0];


// When the user clicks the button, open the modal 
loginbtnl.onclick = function() {
    loginmodall.style.display = 'block';
}
loginbtncl.onclick = function() {
    loginmodall.style.display = 'block';
}
loginbtnbl.onclick = function() {
    loginmodall.style.display = 'block';
}


// When the user clicks on <span> (x), close the modal
loginspanl.onclick = function() {
    loginmodall.style.display = 'none';
}

function validate_loginl()
{
	var usernamel=document.login_forml.txt_usernamel;
	var passwordl=document.login_forml.txt_passwordl;
	
	if(EmptyValidationloginl(usernamel,passwordl))
	{
		
		return true;
	}
	return false;
}

function EmptyValidationloginl(usernamel,passwordl)
{
	var username_lengthl=usernamel.value.length;
	var password_lengthl=passwordl.value.length;
	
	if(username_lengthl==0||password_lengthl==0)
	{
		alert('Please enter Username and Password');
		return false;
	}
	else
	{
		return true;
	}
}

</script>";
?>
