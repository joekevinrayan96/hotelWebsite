

<?php
include('connection.php');

if($_SERVER["REQUEST_METHOD"]=="POST"){
	session_start();
$myusernamep=$_POST['txt_usernamep'];
$mypasswordp=$_POST['txt_passwordp'];
$sqlp="select * from tbl_userdetails where username='$myusernamep' and password='$mypasswordp'";

$resultp=mysqli_query($conn,$sqlp);
$rowp=mysqli_fetch_array($resultp,MYSQLI_ASSOC);
$countp=mysqli_num_rows($resultp);

if($countp==1){
$_SESSION['login_user']=$myusernamep;
$loginsuccessmessagep="Login successfull";
echo "<script type='text/javascript'>
alert('$loginsuccessmessagep');
 window.location='home1.php';
</script>";
//header("location:home1.php");
}
else{
$errorh="Username or Password incorrect";
echo "<script type='text/javascript'>
alert('$errorp');

</script>";
//header("location:loginmodal.php");
}
}


echo '<divm id="loginp" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="closel">&times;</span>
    
    <form name="login_formp" method="post" action="" onsubmit="return validate_loginp();">
    <h1 style="text-align:center">Login</h1>
	<p style="font-size:18px">Username</p>
	<input name="txt_usernamep" type="text" id="txt_usernamep" placeholder="Enter username"/>
	<p style="font-size:18px">Password</p>
	<input name="txt_passwordp" type="password" id="txt_passwordp" placeholder="Enter password"/>
	<p>
  	<input type="submit" name="login_btn_submitp" id="login_btn_submitp" value="Login" />
    </p>
    <p style="text-align:center">or</p>
    <p>
    <ul class="menu" style="text-align:center">
  	<lil id="register_btnp" ><a href="#register">Register</a></lil>
        </ul>
    </p>
</form>
  </div>

</divm>';

echo "<script type='text/javascript'>
// Get the modal
var loginmodalp = document.getElementById('loginp');

// Get the button that opens the modal
var loginbtnp = document.getElementById('login_btnp');
var loginbtncp = document.getElementById('login_btncp');
var loginbtnbp = document.getElementById('login_btnbp');

// Get the <span> element that closes the modal
var loginspanp = document.getElementsByClassName('closel')[0];


// When the user clicks the button, open the modal 
loginbtnp.onclick = function() {
    loginmodalp.style.display = 'block';
}
loginbtncp.onclick = function() {
    loginmodalp.style.display = 'block';
}
loginbtnbp.onclick = function() {
    loginmodalp.style.display = 'block';
}


// When the user clicks on <span> (x), close the modal
loginspanp.onclick = function() {
    loginmodalp.style.display = 'none';
}

function validate_loginp()
{
	var usernamep=document.login_formp.txt_usernamep;
	var passwordp=document.login_formp.txt_passwordp;
	
	if(EmptyValidationloginp(usernamep,passwordp))
	{
		
		return true;
	}
	return false;
}

function EmptyValidationloginp(usernamep,passwordp)
{
	var username_lengthp=usernamep.value.length;
	var password_lengthp=passwordp.value.length;
	
	if(username_lengthp==0||password_lengthp==0)
	{
		alert('Please enter Username and Password');
		return false;
	}
	else
	{
		return true;
	}
}

</script>";
?>
