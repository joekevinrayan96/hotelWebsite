

<?php
include('connection.php');

if($_SERVER["REQUEST_METHOD"]=="POST"){
	session_start();
$myusernameh=$_POST['txt_usernameh'];
$mypasswordh=$_POST['txt_passwordh'];
$sqlh="select * from tbl_userdetails where username='$myusernameh' and password='$mypasswordh'";

$resulth=mysqli_query($conn,$sqlh);
$rowh=mysqli_fetch_array($resulth,MYSQLI_ASSOC);
$counth=mysqli_num_rows($resulth);

if($counth==1){
$_SESSION['login_user']=$myusernameh;
$loginsuccessmessageh="Login successfull";
echo "<script type='text/javascript'>
alert('$loginsuccessmessageh');
 window.location='home1.php';
</script>";
//header("location:home1.php");
}
else{
$errorh="Username or Password incorrect!";
echo "<script type='text/javascript'>
alert('$errorh');

</script>";
//header("location:loginmodal.php");
}
}


echo '<divm id="loginh" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="closel">&times;</span>
    
    <form name="login_formh" method="post" action="" onsubmit="return validate_loginh();">
    <h1 style="text-align:center">Login</h1>
	<p style="font-size:18px">Username</p>
	<input name="txt_usernameh" type="text" id="txt_usernameh" placeholder="Enter username"/>
	<p style="font-size:18px">Password</p>
	<input name="txt_passwordh" type="password" id="txt_passwordh" placeholder="Enter password"/>
	<p>
  	<input type="submit" name="login_btn_submith" id="login_btn_submith" value="Login" />
    </p>
    <p style="text-align:center">or</p>
    <p>
    <ul class="menu" style="text-align:center">
  	<lil id="register_btnh" ><a href="#register">Register</a></lil>
        </ul>
    </p>
</form>
  </div>

</divm>';

echo "<script type='text/javascript'>
// Get the modal
var loginmodalh = document.getElementById('loginh');

// Get the button that opens the modal
var loginbtnh = document.getElementById('login_btnh');
var loginbtnch = document.getElementById('login_btnch');
var loginbtnbh = document.getElementById('login_btnbh');

// Get the <span> element that closes the modal
var loginspanh = document.getElementsByClassName('closel')[0];


// When the user clicks the button, open the modal 
loginbtnh.onclick = function() {
    loginmodalh.style.display = 'block';
}
loginbtnch.onclick = function() {
    loginmodalh.style.display = 'block';
}
loginbtnbh.onclick = function() {
    loginmodalh.style.display = 'block';
}


// When the user clicks on <span> (x), close the modal
loginspanh.onclick = function() {
    loginmodalh.style.display = 'none';
}

function validate_loginh()
{
	var usernameh=document.login_formh.txt_usernameh;
	var passwordh=document.login_formh.txt_passwordh;
	
	if(EmptyValidationloginh(usernameh,passwordh))
	{
		
		return true;
	}
	return false;
}

function EmptyValidationloginh(usernameh,passwordh)
{
	var username_lengthh=usernameh.value.length;
	var password_lengthh=passwordh.value.length;
	
	if(username_lengthh==0||password_lengthh==0)
	{
		alert('Please enter Username and Password');
		return false;
	}
	else
	{
		return true;
	}
}

</script>";
?>
