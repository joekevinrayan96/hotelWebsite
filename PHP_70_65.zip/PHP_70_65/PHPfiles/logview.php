<?php
include('connection.php');
session_start();
$user_check=$_SESSION['login_user'];

$ses_sql=mysqli_query($conn,"select * from users where userName='$user_check'");
$row=mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);

//error handling
if(!$row){
	printf("Error: %s\n", mysqli_error($conn));
	exit();
}

$login_session=$row['userName'];
if(!isset($_SESSION['login_user'])){
	header("location:home.php");
}
	

?>
<ul class="opaquea" style="text-align:right">
	
	<li style="list-style-type:none;float:right;"><a href="#login">Login</a></li>
    <li id="loginbtn" style="list-style-type:none;float:right">Guest &nbsp;</li>
</ul>

