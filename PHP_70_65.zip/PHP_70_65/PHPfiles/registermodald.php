<divm id="registerd" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="closer">&times;</span>
    <form name="register_formd" method="post" action="" onsubmit="return validate_registerd();">
    <h1 style="text-align:center">Register</h1>
<p style="font-size:18px">First Name</p>
<input name="txt_firstnamerd" type="text" id="txt_firstnamerd" placeholder="Your First Name"/>
<p style="font-size:18px">Last Name</p>
<input name="txt_lastnamerd" type="text" id="txt_lastnamerd" placeholder="Your Last Name"/>
<p style="font-size:18px">Email</p>
<input name="txt_emailrd" type="text" id="txt_emailrd" placeholder="Your email address"/>
<p style="font-size:18px">Contact No</p>
<input name="txt_mobilerd" type="text" id="txt_mobilerd" placeholder="Your mobile No." />
<p style="font-size:18px">Username</p>
<input name="txt_usernamerd" type="text" id="txt_usernamerd" placeholder="Create a username" />
<p style="font-size:18px">Password</p>
<input name="txt_passwordrd" type="password" id="txt_passwordrd" placeholder="Enter a password" />
<p style="font-size:18px">Re-enter Password</p>
<input name="txt_repasswordrd" type="text" id="txt_repasswordrd" placeholder="Re-enter the password" />

<p>
  <input type="submit" name="register_btn_submitrd" id="register_btn_submitrd" value="Submit" />
</p>
</form>
  </div>

</divm>

<script type="text/javascript">
// Get the modal
var registermodald = document.getElementById('registerd');

// Get the button that opens the modal
var registerbtnd = document.getElementById("register_btnd");

// Get the <span> element that closes the modal
var registerspand = document.getElementsByClassName("closer")[0];

// When the user clicks the button, open the modal 
registerbtnd.onclick = function() {
    registermodald.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
registerspand.onclick = function() {
    registermodald.style.display = "none";
}

function validate_registerd()
{
	var firstnamerd=document.register_formd.txt_firstnamerd;
	var lastnamerd=document.register_formd.txt_lastnamerd;
	var emailrd=document.register_formd.txt_emailrd;
	var contactnord=document.register_formd.txt_mobilerd;
	var usernamerd=document.register_formd.txt_usernamerd;
	var passwordrd=document.register_formd.txt_passwordrd;
	var repasswordrd=document.register_formd.txt_repasswordrd;
	
	if(EmptyValidationregisterd(firstnamerd,lastnamerd,emailrd,contactnord,usernamerd,passwordrd,repasswordrd))
	{
		if(AllLettersregisterd(firstnamerd,lastnamerd))
		{
			if(Emailregisterd(emailrd))
			{
				if(Allnumericregisterd(contactnord))
				{
					if(passwordrd.getText().toString().equals(repasswordrd))
					{
						alert("You have successfully registered");
							return true;
					}
				}
			}
		}
		
	}
	return false;
	
	
}

function EmptyValidationregisterd(firstnamerd,lastnamerd,emailrd,contactnord,usernamerd,passwordrd,repasswordrd)
{
	var firstname_lengthrd=firstnamerd.value.length;
	var lastname_lengthrd=lastnamerd.value.length;
	var email_lengthrd=emailrd.value.length;
	var contactno_lengthrd=contactnord.value.length;
	var username_lengthrd=usernamerd.value.length;
	var password_lengthrd=passwordrd.value.length;
	var repassword_lengthrd=repasswordrd.value.length;
	
	if(firstname_lengthrd==0||lastname_lengthrd==0||email_lengthrd==0||contactno_lengthrd==0||username_lengthrd==0||password_lengthrd==0||repassword_lengthrd==0)
	{
		alert("Fields should not be empty");
		return false;
			
	}
	else
	{
		return true;
	}
	
}

function AllLettersregisterd(firstnamebrd,lastnamerd)
{
	var lettersrd=/^[A-Za-z]+$/;
	if(firstnamerd.value.match(lettersrd)&&lastnamerd.value.match(lettersrd))
	{
		return true;
	}
	else
	{
		alert('Firstname and Lastname should contain only alphabets');
		firstnamerd.focus();
		return false;
	}
}


function Emailregisterd(emailrd)
{
	var letterrd=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if(emailrd.value.match(letterrd))
	{

		return true;
	}
	else
	{
		alert("Invalid email format")
		emailrd.focus();
		return false;
	}
}

function Allnumericregisterd(contactnord)
{
	var lettersnrd=/^[0-9]+$/;
	if(contactnord.value.match(lettersnrd))
	{
		return true;
	}
	else
	{
		alert("mobile no should contain only numbers");
		mobilerd.focus();
		return false;
	}
}




</script>

<?php
if(isset($_POST['register_btn_submitrd']))
{
include('connection.php');

$firstnamerd=$_POST['txt_firstnamerd'];
$lastnamerd=$_POST['txt_lastnamerd'];
$emailrd=$_POST['txt_emailrd'];
$mobilerd=$_POST['txt_mobilerd'];
$usernamerd=$_POST['txt_usernamerd'];
$passwordrd=$_POST['txt_passwordrd'];

$checkrd="select * from tbl_userdetails where username='$usernamerd'";
$rsd=mysqli_query($conn,$checkrd);
$data1rd=mysqli_fetch_array($rsd, MYSQLI_NUM);
if($data1rd[0]>1)
{
	echo "User already exists</br>";
}
else
{

$sqlrd="insert into tbl_userdetails values('$firstnamerd','$lastnamerd','$emailrd','$mobilerd','$usernamerd','$passwordrd')";
$datard=mysqli_query($conn,$sqlrd);
if($datard)
{
echo "You have successfully registered";
}
else
{
die('could not enter data'.mysqli_error());
}
}

}
?>
