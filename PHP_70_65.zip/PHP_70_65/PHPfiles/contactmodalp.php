<?php include('session.php'); ?>
 <!-- The Modal -->
<divm id="contactp" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="closec">&times;</span>
    <form name="contact_formp" method="post" action="home.html" onsubmit="return validate_contactp();">
    <h1 style="text-align:center">Contact Us</h1>
<p style="font-size:18px">Name</p>
<input name="txt_fullnamecp" type="text" id="txt_fullnamecp" placeholder="Your Name"/>
<p style="font-size:18px">Email</p>
<input name="txt_emailcp" type="text" id="txt_emailcp" placeholder="Your email address"/>
<p style="font-size:18px">Inquiry</p>
<textarea name="txt_inquirycp" rows="5"   type="text" id="txt_inquirycp" placeholder="Your inquiry"></textarea>

<p>
  <input type="submit" name="contact_btn_submitp" id="contact_btn_submitp" value="Submit" />
  
</p>

<p style="font-size:12px">For more details call: 011-2451932</p>

</form>
  </div>

</divm>

<script type="text/javascript">
// Get the modal
var contactmodalp = document.getElementById('contactp');

// Get the button that opens the modal
var contactbtnp = document.getElementById("contact_btncp");

// Get the <span> element that closes the modal
var contactspanp = document.getElementsByClassName("closec")[0];

// When the user clicks the button, open the modal 
contactbtnp.onclick = function() {
    contactmodalp.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
contactspanp.onclick = function() {
    contactmodalp.style.display = "none";
}

function validate_contactp()
{
	var namecp=document.contact_formp.txt_fullnamecp;
	var emailcp=document.contact_formp.txt_emailcp;
	var inquirycp=document.contact_formp.txt_inquirycp;
	
	if(EmptyValidationcontactp(namecp,emailcp,inquirycp))
	{
		if(AllLetterscontactp(namecp))
		{
			if(Emailcontactp(emailcp))
			{
				alert("Your inquiry is sent successfully");
				return true;
			}
		}
		
	}
	return false;
	
	
}

function EmptyValidationcontactp(namecp,emailcp,inquirycp)
{
	var name_lengthcp=namecp.value.length;
	var email_lengthcp=emailcp.value.length;
	var inquiry_lengthcp=inquirycp.value.length;
	
	if(name_lengthcp==0||email_lengthcp==0||inquiry_lengthcp==0)
	{
		alert("Fields should not be empty");
		return false;
			
	}
	else
	{
		return true;
	}
	
}

function AllLetterscontactp(namecp)
{
	var letterscp=/^[A-Za-z]+$/;
	if(namecp.value.match(letterscp))
	{
		return true;
	}
	else
	{
		alert("Name should contain only alphabets");
		namecp.focus();
		return false;
	}
}


function Emailcontactp(emailcp)
{
	var lettercp=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if(emailcp.value.match(lettercp))
	{
		return true;
	}
	else
	{
		alert("Invalid email format");
		emailcp.focus();
		return false;
	}
}


</script>

<?php
if(isset($_POST['contact_btn_submitp']))
{
include('connection.php');

$namecp=$_POST['txt_fullnamecp'];
$emailcp=$_POST['txt_emailcp'];
$mobilecp=$_POST['txt_mobilecp'];

$sqlcp="insert into tbl_inquirydetails values('$login_session','$namecp','$emailcp','$mobilecp')";
$datach=mysqli_query($conn,$sqlch);
if($datacp)
{
echo "You inquiry has been sent";
}
else
{
die('could not enter data'.mysqli_error());
}
}

?>
