<divm id="logregb" class="log">

  <!-- Modal content -->
  <div class="modal-content-login">
    <span class="closeb">&times;</span>
    <form name="login" method="post" action="home.html" onsubmit="return formValidationb();">
    <h1 style="text-align:center">Book Now</h1>
<p style="font-size:18px">Username</p>
<input name="usernamel" type="text" id="usernamel" placeholder="Enter username"/>
<p style="font-size:18px">Password</p>
<input name="passwordl" type="password" id="passwordl" placeholder="Enter password"/>


<p>
  <input type="submit" name="btnlogin" id="btnlogin" value="Submit" />
  <input type="button" name="btnregister" id="btnlogin" value="Submit"/>

</p>



</form>
  </div>

</divm>

<script type="text/javascript">
// Get the modal
var modall = document.getElementById('logregb');

// Get the button that opens the modal
var btnl = document.getElementById("logreg");

// Get the <span> element that closes the modal
var spanl = document.getElementsByClassName("closeb")[0];

// When the user clicks the button, open the modal 
btnl.onclick = function() {
    modalb.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
spanl.onclick = function() {
    modall.style.display = "none";
}

function formValidationl()
{
	var usnamel=document.login.firstnameb;
	var lnameb=document.booknowfb.lastnameb;
	var emailb=document.booknowfb.emailb;
	var contactnob=document.booknowfb.mobileb;
	var checkinb=document.booknowfb.checkinb;
	var checkoutb=document.booknowfb.checkoutb;
	var roomb=document.booknowfb.roomsib;
	
	if(EmptyValidationb(fnameb,lnameb,emailb,contactnob,checkinb,checkoutb,roomb))
	{
		if(AllLettersb(fnameb,lnameb))
		{
			if(Emailb(emailb))
			{
				if(Allnumericb(contactnob))
				{
					if(!checkinb.getText().toString().equals("mm/dd/yyyy"))
					{
						if(!checkoutb.getText().toString().equals("mm/dd/yyyy"))
						{
							alert("Booking Details successfully sent!");
							return true;
						}
					}
				}
			}
		}
		
	}
	return false;
	
	
}

function EmptyValidationb(fnameb,lnameb,emailb,contactnob,checkinb,checkoutb,roomb)
{
	var fnameb_lenb=fnameb.value.length;
	var lnameb_lenb=lnameb.value.length;
	var emailab_lenb=emailb.value.length;
	var contactnob_lenb=contactnob.value.length;
	var checkinb_lenb=checkinb.value.length;
	var checkoutb_lenb=checkoutb.value.length;
	var roomb_lenb=roomb.value.length;
	
	if(fnameb_lenb==0||lnameb_lenb==0||emailab_lenb==0||contactnob_lenb==0||checkinb_lenb==0||checkoutb_lenb==0||roomb_lenb==0)
	{
		alert("Fields should not be empty");
		return false;
			
	}
	else
	{
		return true;
	}
	
}

function AllLettersb(fnameb,lnameb)
{
	var lettersb=/^[A-Za-z]+$/;
	if(fnameb.value.match(lettersb)&&lnameb.value.match(lettersb))
	{
		return true;
	}
	else
	{
		alert('Firstname and Lastname should contain only alphabets');
		fnameb.focus();
		return false;
	}
}


function Emailb(emailb)
{
	var letterb=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if(emailb.value.match(letterb))
	{
		return true;
	}
	else
	{
		alert("Invalid email format")
		emailb.focus();
		return false;
	}
}

function Allnumericb(contactnob)
{
	var lettersnb=/^[0-9]+$/;
	if(contactnob.value.match(lettersnb))
	{
		return true;
	}
	else
	{
		alert("mobile no should contain only numbers");
		mobileb.focus();
		return false;
	}
}




</script>
