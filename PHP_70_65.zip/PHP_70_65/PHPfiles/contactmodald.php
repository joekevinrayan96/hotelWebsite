<?php include('session.php'); ?>
 <!-- The Modal -->
<divm id="contactd" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="closec">&times;</span>
    <form name="contact_formd" method="post" action="home.html" onsubmit="return validate_contactd();">
    <h1 style="text-align:center">Contact Us</h1>
<p style="font-size:18px">Name</p>
<input name="txt_fullnamecd" type="text" id="txt_fullnamecd" placeholder="Your Name"/>
<p style="font-size:18px">Email</p>
<input name="txt_emailcd" type="text" id="txt_emailcd" placeholder="Your email address"/>
<p style="font-size:18px">Inquiry</p>
<textarea name="txt_inquirycd" rows="5"   type="text" id="txt_inquirycd" placeholder="Your inquiry"></textarea>

<p>
  <input type="submit" name="contact_btn_submitd" id="contact_btn_submitd" value="Submit" />
  
</p>

<p style="font-size:12px">For more details call: 011-2451932</p>

</form>
  </div>

</divm>

<script type="text/javascript">
// Get the modal
var contactmodald = document.getElementById('contactd');

// Get the button that opens the modal
var contactbtnd = document.getElementById("contact_btncd");

// Get the <span> element that closes the modal
var contactspand = document.getElementsByClassName("closec")[0];

// When the user clicks the button, open the modal 
contactbtnd.onclick = function() {
    contactmodald.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
contactspand.onclick = function() {
    contactmodald.style.display = "none";
}

function validate_contactd()
{
	var namecd=document.contact_formd.txt_fullnamecd;
	var emailcd=document.contact_formd.txt_emailcd;
	var inquirycd=document.contact_formd.txt_inquirycd;
	
	if(EmptyValidationcontactd(namecd,emailcd,inquirycd))
	{
		if(AllLetterscontactd(namecd))
		{
			if(Emailcontactd(emailcd))
			{
				alert("Your inquiry is sent successfully");
				return true;
			}
		}
		
	}
	return false;
	
	
}

function EmptyValidationcontactd(namecd,emailcd,inquirycd)
{
	var name_lengthcd=namecd.value.length;
	var email_lengthcd=emailcd.value.length;
	var inquiry_lengthcd=inquirycd.value.length;
	
	if(name_lengthcd==0||email_lengthcd==0||inquiry_lengthcd==0)
	{
		alert("Fields should not be empty");
		return false;
			
	}
	else
	{
		return true;
	}
	
}

function AllLetterscontactd(namecd)
{
	var letterscd=/^[A-Za-z]+$/;
	if(namecd.value.match(letterscd))
	{
		return true;
	}
	else
	{
		alert("Name should contain only alphabets");
		namecd.focus();
		return false;
	}
}


function Emailcontactd(emailcd)
{
	var lettercd=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if(emailcd.value.match(lettercd))
	{
		return true;
	}
	else
	{
		alert("Invalid email format");
		emailcd.focus();
		return false;
	}
}


</script>

<?php
if(isset($_POST['contact_btn_submitd']))
{
include('connection.php');

$namecd=$_POST['txt_fullnamecd'];
$emailcd=$_POST['txt_emailcd'];
$mobilecd=$_POST['txt_mobilecd'];

$sqlcd="insert into tbl_inquirydetails values('$login_session','$namecd','$emailcd','$mobilecd')";
$datacd=mysqli_query($conn,$sqlcd);
if($datacd)
{
echo "You inquiry has been sent";
}
else
{
die('could not enter data'.mysqli_error());
}
}

?>
