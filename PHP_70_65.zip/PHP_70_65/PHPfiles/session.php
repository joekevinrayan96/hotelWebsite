<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
include('connection.php');
session_start();
if(!isset($_SESSION['login_user'])){
	echo "<script type='text/javascript'>
 window.location='home.php';
</script>";
//header("location:home.php");
}

$user_check=$_SESSION['login_user'];

$ses_sql=mysqli_query($conn,"select * from tbl_userdetails where username='$user_check'");
$row=mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);

if(!$row){
printf("Error: %s\n", mysqli_error($conn));
exit();
}

$login_session=$row['username'];
?>
</body>
</html>